#!/bin/bash
roslaunch turtlebot3_bringup turtlebot3_robot.launch
