sudo systemctl restart systemd-networkd
